# ci-rest-server
Restful API menggunakan Code Igniter 3.1.11
